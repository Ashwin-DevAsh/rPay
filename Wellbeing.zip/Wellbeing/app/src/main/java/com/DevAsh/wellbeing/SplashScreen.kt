package com.DevAsh.wellbeing

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.DevAsh.wellbeing.Pages.Config.Settings
import com.DevAsh.wellbeing.Context.AppsContext
import com.DevAsh.wellbeing.Context.UserContext
import com.DevAsh.wellbeing.Database.AllowedApp
import com.DevAsh.wellbeing.Database.BasicSettings
import com.DevAsh.wellbeing.Database.RealmHelper
import com.DevAsh.wellbeing.Database.User
import io.realm.Realm
import io.realm.RealmList
import kotlinx.android.synthetic.main.activity_settings.*


class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        RealmHelper.init(this)
        Handler().post{
            getUsers()
            loadApps()
        }
        openActivity()
    }

    private fun openActivity(){
        Handler().postDelayed({
            startActivity(Intent(this, Settings::class.java))
            finish()
        }, 2000)
    }

    private fun getUsers(){
       UserContext.user = Realm.getDefaultInstance().where(User::class.java).findFirst()
       if(UserContext.user==null){
           Realm.getDefaultInstance().executeTransactionAsync{
               UserContext.user = User(RealmList<AllowedApp>(), BasicSettings())
               it.insertOrUpdate(UserContext.user!!)
           }
       }
    }

    private fun loadApps(){
        val i = Intent(Intent.ACTION_MAIN, null)
        i.addCategory(Intent.CATEGORY_LAUNCHER)
        val availableApps = packageManager.queryIntentActivities(i, 0)
        AppsContext.allApps = availableApps
        val allowedApps = UserContext.user!!.allowedApps
        AppsContext.allowedApps.clear()
        for(i in availableApps){
            if(allowedApps.contains(AllowedApp(i.activityInfo.packageName))){
                AppsContext.allowedApps.add(i)
            }
        }
    }




}