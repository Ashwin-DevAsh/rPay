package com.DevAsh.wellbeing.Pages.Config

import android.content.Context
import android.content.pm.ResolveInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.DevAsh.wellbeing.Context.AppsContext
import com.DevAsh.wellbeing.Context.UserContext
import com.DevAsh.wellbeing.Database.AllowedApp
import com.DevAsh.wellbeing.Database.RealmHelper
import com.DevAsh.wellbeing.R
import io.realm.RealmList
import kotlinx.android.synthetic.main.activity_allow_apps.*
import kotlinx.android.synthetic.main.widget_gridtile_app.view.*
import net.igenius.customcheckbox.CustomCheckBox
import java.util.*
import kotlin.collections.ArrayList

class AllowApps : AppCompatActivity() {


    companion object{
        var appsAdapter:AppsAdapter? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_allow_apps)
        RealmHelper.init(this)
        searchBar.hint = "Search among ${AppsContext.allApps.size} apps"
        loadAdapter()
        Settings.handelAppBar(scroller,appBar)
        handelSearch()
        onClick()
    }

    private fun onClick(){
        done.setOnClickListener {
            saveData()
        }
    }

    private fun loadAdapter(){

        Handler().postDelayed({
            AppsContext.allApps.removeAll(AppsContext.allowedApps)
            AppsContext.allApps.addAll(0,AppsContext.allowedApps)
            if(appsAdapter==null){
                appsAdapter = AppsAdapter(ArrayList(AppsContext.allApps),this)
            }else{
                appsAdapter?.allowedAppsClone = ArrayList(AppsContext.allowedApps)
                appsAdapter?.updateList(ArrayList(AppsContext.allApps))
            }
            appsContainer.layoutManager = GridLayoutManager(this,4)
            appsContainer.adapter = appsAdapter
            scroller.visibility=View.VISIBLE
            loadingScreen.visibility=View.GONE
        },1000)
    }

    private fun handelSearch(){
        searchBar.addTextChangedListener(object:TextWatcher{
            var handler=Handler()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().toLowerCase(Locale.ROOT)
                handler.removeCallbacksAndMessages(true)
                handler.postDelayed({
                    appsAdapter?.items?.clear()
                    for(i in AppsContext.allApps){
                        if(i.loadLabel(this@AllowApps.packageManager).toString().toLowerCase(Locale.ROOT)
                                .contains(query)){
                            appsAdapter?.items?.add(i)
                        }
                    }
                    appsAdapter?.notifyDataSetChanged()
                },100)
            }
            override fun afterTextChanged(s: Editable?) {

            }
        })
    }

    private fun saveData(){
        AppsContext.allowedApps= ArrayList(appsAdapter?.allowedAppsClone!!)
        val allowedApps = RealmList<AllowedApp>()
        for(i in AppsContext.allowedApps){
            allowedApps.add(AllowedApp(i.activityInfo.packageName))
        }

        RealmHelper.updateUser(UserContext.user?.getNewObject(allowedApps)!!)
        finish()
    }


}

class AppsAdapter( var items : MutableList<ResolveInfo>, private val context: Context) : RecyclerView.Adapter<ViewHolder>() {

    var allowedAppsClone = ArrayList(AppsContext.allowedApps)


    override fun getItemCount(): Int {
        return items.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(
            R.layout.widget_gridtile_app, parent, false),
            allowedAppsClone
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.item = items[position]
        holder.packageName = items[position].loadLabel(context.packageManager).toString()
        holder.name.text = holder.packageName
        holder.icon.setImageDrawable(items[position].loadIcon(context.packageManager))
        if(allowedAppsClone.contains(items[position])){
              holder.checkBox.setChecked(true,false)
        }else{
            holder.checkBox.setChecked(false,false)
        }
    }

    fun updateList(updatedList : MutableList<ResolveInfo>){
        this.items = updatedList
        notifyDataSetChanged()
    }
}

class ViewHolder (view: View,allowedApps:ArrayList<ResolveInfo>) : RecyclerView.ViewHolder(view) {
    val name = view.findViewById(R.id.name) as TextView
    val icon = view.findViewById(R.id.icon) as ImageView
    val checkBox =  view.checkbox as CustomCheckBox
    var packageName:String?=null
    var item:ResolveInfo?=null

    init {
        view.setOnClickListener{
            if(!checkBox.isChecked){
                checkBox.setChecked(true,true)
                allowedApps.add(item!!)

            }else{
                checkBox.setChecked(false,true)
                allowedApps.remove(item)
            }
        }
    }
}

