package com.DevAsh.wellbeing.Pages.Config.Fragments

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.os.Handler
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.DevAsh.wellbeing.Pages.Config.AllowApps
import com.DevAsh.wellbeing.Context.AppsContext
import com.DevAsh.wellbeing.R
import kotlinx.android.synthetic.main.sheet_allowed_apps.view.*



class AllowedAppsBottomSheet(private val parentContext:Activity) : BottomSheetDialogFragment() {

    companion object{
        var allowedAppsAdapter:AllowedAppsAdapter?=null
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.sheet_allowed_apps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        view.add.setOnClickListener{
            this.dismiss()
            startActivityForResult(Intent(parentContext,AllowApps::class.java),0)
        }

        Handler().postDelayed({
            view.allowedApps?.layoutManager = LinearLayoutManager(context)
            if(allowedAppsAdapter==null){
                allowedAppsAdapter = AllowedAppsAdapter(ArrayList(AppsContext.allowedApps),parentContext)
            }else{
                allowedAppsAdapter?.updateList(ArrayList(AppsContext.allowedApps))
            }
            view.allowedApps?.adapter= allowedAppsAdapter
            view.mainContent.visibility=View.VISIBLE
            view.loadingScreen.visibility=View.GONE
        },1000)

    }

     class AllowedAppsAdapter(
        private var items : MutableList<ResolveInfo>,
        private val context: Activity
    ) : RecyclerView.Adapter<ViewHolder>() {

        override fun getItemCount(): Int {
            return items.size
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(context)
                .inflate(R.layout.widget_listtile_apps, parent, false), context)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.name.text = items[position].loadLabel(context.packageManager)
            holder.icon.setImageDrawable(items[position].loadIcon(context.packageManager))
            holder.packageName.text = items[position].activityInfo.packageName
        }

        fun updateList(updatedList : MutableList<ResolveInfo>){
            this.items = updatedList
            notifyDataSetChanged()
        }
    }

     class ViewHolder (view: View, context: Activity) : RecyclerView.ViewHolder(view) {
        val name = view.findViewById(R.id.name) as TextView
        val icon = view.findViewById(R.id.icon) as ImageView
        val packageName = view.findViewById(R.id.packageName) as TextView
    }
}


