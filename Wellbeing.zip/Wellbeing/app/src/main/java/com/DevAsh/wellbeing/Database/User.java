package com.DevAsh.wellbeing.Database;

import io.realm.RealmList;
import io.realm.RealmObject;

public class User extends RealmObject {
    public RealmList<AllowedApp> allowedApps;
    public BasicSettings basicSettings;

    public User(RealmList<AllowedApp> allowedApps, BasicSettings basicSettings) {
        this.allowedApps = allowedApps;
        this.basicSettings = basicSettings;
    }

    public User(){}

    public User getNewObject(RealmList<AllowedApp> allowedApps){
        return new User(allowedApps,this.basicSettings);
    }

    public User getNewObject(BasicSettings basicSettings){
        RealmList<AllowedApp> allowedApps= new RealmList();
        allowedApps.addAll(this.allowedApps);
        return new User(allowedApps,basicSettings);
    }


}
