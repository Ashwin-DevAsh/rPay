package com.DevAsh.wellbeing.Layouts

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.RelativeLayout

class CustomImageView : RelativeLayout {
    var mInflater: LayoutInflater

    constructor(context: Context?) : super(context) {
        mInflater = LayoutInflater.from(context)

    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val newWidth = measuredWidth
        setMeasuredDimension(newWidth, newWidth)
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(context,
        attrs,
        defStyle) {
        mInflater = LayoutInflater.from(context)

    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        mInflater = LayoutInflater.from(context)

    }


}