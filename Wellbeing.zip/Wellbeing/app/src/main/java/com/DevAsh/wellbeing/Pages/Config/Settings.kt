package com.DevAsh.wellbeing.Pages.Config

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.DevAsh.wellbeing.Pages.Config.Fragments.AllowedAppsBottomSheet
import com.DevAsh.wellbeing.Context.AppsContext
import com.DevAsh.wellbeing.Context.UserContext
import com.DevAsh.wellbeing.Database.BasicSettings
import com.DevAsh.wellbeing.Database.RealmHelper
import com.DevAsh.wellbeing.Pages.Kiosk.Launcher
import com.DevAsh.wellbeing.R
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.android.synthetic.main.activity_settings.*
import kotlinx.android.synthetic.main.sheet_options.view.*


class Settings : AppCompatActivity() {

    private val allowedAppsFragment= AllowedAppsBottomSheet(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RealmHelper.init(this)
        setContentView(R.layout.activity_settings)
        loadView()
        onClick()
        handelAppBar(scroller,appBar)
    }

    private fun onClick(){
        done?.setOnClickListener {
            startActivity(Intent(this,Launcher::class.java))
        }

        permission.setOnClickListener {
            startActivity(Intent(this,Permissions::class.java))
        }

        wifi?.setOnClickListener{
            openBottomSheet(wifiMode)
        }
        hotspot?.setOnClickListener{
            openBottomSheet(hotspotMode)
        }
        bluetooth?.setOnClickListener{
            openBottomSheet(bluetoothMode)
        }
        mobileData?.setOnClickListener {
            openBottomSheet(mobiledataMode,false)
        }
        notification?.setOnClickListener{
            openBottomSheet(notificationMode,false)
        }
        phoneCall?.setOnClickListener {
            openBottomSheet(
                phoneCallMode,
                advanceOptions = false,
                additionalOption = true
            )
        }
        apps.setOnClickListener {
            openApps()
        }
    }

    private fun loadView(){
        wifiMode?.text = UserContext.user?.basicSettings?.wifi
        hotspotMode?.text = UserContext.user?.basicSettings?.hotspot
        bluetoothMode?.text = UserContext.user?.basicSettings?.bluetooth
        mobiledataMode?.text = UserContext.user?.basicSettings?.mobileData
        notificationMode?.text = UserContext.user?.basicSettings?.notificationPanel

    }

    override fun onBackPressed() {
        saveData()
        super.onBackPressed()
    }

    private fun saveData(){
        val basicSettings = BasicSettings(
            wifiMode.text.toString(),
            hotspotMode.text.toString(),
            bluetoothMode.text.toString(),
            mobiledataMode.text.toString(),
            notificationMode.text.toString()
        )
        RealmHelper.updateUser(UserContext.user!!.getNewObject(basicSettings))
    }

    private fun openApps(){
        if(!AppsContext.allowedApps.isNullOrEmpty()){

            allowedAppsFragment.show(supportFragmentManager, "TAG")
        }else{
             startActivity(Intent(this, AllowApps::class.java))
        }
    }

    private fun openBottomSheet(
        mode:TextView,
        advanceOptions:Boolean=true,
        additionalOption:Boolean=false
    ){

        val options = BottomSheetDialog(this)
        val sheetView: View = LayoutInflater.from(this).inflate(R.layout.sheet_options, null)

        fun onModeClick(
            clickView: View,
            option:String
        ){
            clickView.setOnClickListener{
                mode.text = option
                options.cancel()
            }
        }
        onModeClick(sheetView.allow,"Allow")
        onModeClick(sheetView.deny,"Deny")
        onModeClick(sheetView.alwaysOn,"Always on")
        onModeClick(sheetView.alwaysOff,"Always off")
        onModeClick(sheetView.denyIncoming,"Deny incoming")
        onModeClick(sheetView.denyOutgoing,"Deny outgoing")
        onModeClick(sheetView.whitelist,"Whitelist Calls")
        onModeClick(sheetView.blacklist,"BlackList Calls")
        if(advanceOptions){
            sheetView.advance.visibility=View.VISIBLE
        }else{
            sheetView.advance.visibility=View.GONE
        }
        if(additionalOption){
            sheetView.allow.text = "Allow calls"
            sheetView.deny.text = "Deny calls"
            onModeClick(sheetView.allow,"Allow Calls")
            onModeClick(sheetView.deny,"Deny Calls")
            sheetView.additional.visibility=View.VISIBLE
        }else{
            sheetView.additional.visibility=View.GONE
        }

        options.setContentView(sheetView)
        options.show()
    }

    companion object{
        fun handelAppBar(scroller:View,appBar:CardView){
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)
            scroller.setOnScrollChangeListener { _, _, scrollY, _, _ ->
                if (scrollY >1) {
                   appBar.cardElevation=10f

                }
                if(scrollY < 1){
                    appBar.cardElevation=0f
                }
            }
        }
    }
}