package com.DevAsh.wellbeing.Helpers

import android.content.Context
import android.provider.Settings
import com.DevAsh.wellbeing.Services.WindowChangeDetectingService

object PermissionsHelper {
    fun isAccessServiceEnabled(context: Context, accessibilityServiceClass: Class<*>): Boolean {
        val prefString = Settings.Secure.getString(context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return prefString != null && prefString.contains(context.packageName + "/" + accessibilityServiceClass.name)
    }

    fun checkImportantPermissions(context: Context):Boolean{
        return  isAccessServiceEnabled(context,
                WindowChangeDetectingService::class.java
        )
    }
}