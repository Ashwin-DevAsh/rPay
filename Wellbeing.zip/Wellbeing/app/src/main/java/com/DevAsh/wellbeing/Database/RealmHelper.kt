package com.DevAsh.wellbeing.Database

import android.content.Context
import com.DevAsh.wellbeing.Context.UserContext
import io.realm.Realm

object RealmHelper {
    fun init(context: Context){
        Realm.init(context)
    }

    fun updateUser(user:User){
        Realm.getDefaultInstance().executeTransactionAsync{
            it.delete(User::class.java)
            it.insertOrUpdate(user)
            UserContext.user = user
        }

    }
}