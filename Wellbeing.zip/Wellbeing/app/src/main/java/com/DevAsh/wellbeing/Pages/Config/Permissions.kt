package com.DevAsh.wellbeing.Pages.Config

import android.os.Bundle
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity
import com.DevAsh.wellbeing.R
import kotlinx.android.synthetic.main.activity_permissions.*


class Permissions : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permissions)

    }

}