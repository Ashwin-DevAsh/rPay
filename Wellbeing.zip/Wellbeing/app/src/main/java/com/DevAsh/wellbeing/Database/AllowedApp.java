package com.DevAsh.wellbeing.Database;

import java.util.Objects;

import io.realm.RealmObject;

public class AllowedApp extends RealmObject {
    public String packageName;
    public String hourPerDay;
    public String startAfter;

    public AllowedApp(){}

    public AllowedApp(String packageName, String hourPerDay, String startAfter) {
        this.packageName = packageName;
        this.hourPerDay = hourPerDay;
        this.startAfter = startAfter;
    }

    public  AllowedApp(String packageName){
        this.packageName=packageName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AllowedApp)) return false;
        AllowedApp that = (AllowedApp) o;
        return Objects.equals(packageName, that.packageName);
    }

}
