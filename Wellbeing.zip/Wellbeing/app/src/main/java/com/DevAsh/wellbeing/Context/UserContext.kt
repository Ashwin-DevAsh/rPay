package com.DevAsh.wellbeing.Context

import com.DevAsh.wellbeing.Database.User
import io.realm.RealmResults

object UserContext {
    var user : User? = null
}