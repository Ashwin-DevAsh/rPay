package com.DevAsh.wellbeing.Database;

import java.util.Objects;

import io.realm.RealmObject;

public class BasicSettings extends RealmObject {
    public String wifi = "Deny";
    public String hotspot = "Deny";
    public String bluetooth = "Deny";
    public String mobileData = "Deny";
    public String notificationPanel = "Deny";

    public BasicSettings(String wifi, String hotspot, String bluetooth, String mobileData, String notificationPanel) {
        this.wifi = wifi;
        this.hotspot = hotspot;
        this.bluetooth = bluetooth;
        this.mobileData = mobileData;
        this.notificationPanel = notificationPanel;
    }

    public BasicSettings(){}

}
