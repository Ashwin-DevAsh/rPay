package com.DevAsh.wellbeing.Context

import android.content.pm.ResolveInfo

object AppsContext {
    var allApps= mutableListOf<ResolveInfo>()
    var allowedApps = mutableListOf<ResolveInfo>()
}